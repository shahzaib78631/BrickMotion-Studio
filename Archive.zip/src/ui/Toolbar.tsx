import { useEffect, useRef, useState, type ReactNode } from 'react';
import { exportLDraw } from '../io/ldrawExport';
import { planToJson, readPlanFile } from '../io/planFile';
import { isProjectFile, readProjectFile, PROJECT_EXTENSION } from '../io/projectFile';
import { animOptions, useAppSettings } from '../state/appSettings';
import { adoptTimeline, forgetTimelines, optsKey, settingsFromOptsKey } from '../state/timelineService';
import { regenerateSteps } from '../plan/regenerate';
import { saveProjectFile, type SaveProgress } from '../state/projectActions';
import { splitPlanComponents } from '../plan/components';
import { ensureIds } from '../plan/ids';
import { autoStepPlan, modelsWithoutSteps } from '../plan/autoSteps';
import { ensureParts, getColors, metricsOf, registerInlineParts } from '../state/partService';
import { allPartIds } from '../state/useModel';
import { newProject, useSaveStatus } from '../state/persistence';
import { useStudio } from '../state/store';
import { saveBlob, safeFileName } from './download';
import { Ic, type IconName } from './icons';

export function pieceCount(plan = useStudio.getState().plan): number {
  return [...plan.steps, ...Object.values(plan.submodels ?? {}).flatMap((s) => s.steps)].reduce((n, s) => n + s.pieces.length, 0);
}

export type MenuItem = { icon: IconName; label: string; onClick(): void; disabled?: boolean; hint?: string; danger?: boolean; current?: boolean } | 'sep';

/** A button that opens a kit-style menu under it. */
export function DropMenu({
  trigger,
  items,
  className,
  align = 'left',
  label,
}: {
  trigger: ReactNode;
  items: MenuItem[];
  className: string;
  align?: 'left' | 'right';
  label: string;
}) {
  const [pos, setPos] = useState<{ x: number; y: number } | null>(null);
  const btn = useRef<HTMLButtonElement>(null);
  const menu = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!pos) return;
    const close = (e: Event) => {
      if (e instanceof KeyboardEvent && e.key !== 'Escape') return;
      if (e.target instanceof Node && (menu.current?.contains(e.target) || btn.current?.contains(e.target))) return;
      setPos(null);
    };
    window.addEventListener('pointerdown', close);
    window.addEventListener('keydown', close);
    return () => {
      window.removeEventListener('pointerdown', close);
      window.removeEventListener('keydown', close);
    };
  }, [pos]);
  return (
    <>
      <button
        ref={btn}
        className={`${className} ${pos ? 'on' : ''}`}
        aria-haspopup="menu"
        aria-expanded={!!pos}
        aria-label={label}
        onClick={() => {
          if (pos) return setPos(null);
          const r = btn.current!.getBoundingClientRect();
          setPos({ x: align === 'right' ? r.right : r.left, y: r.bottom + 6 });
        }}
      >
        {trigger}
      </button>
      {pos && (
        <div
          ref={menu}
          className="nx-menu"
          role="menu"
          style={align === 'right' ? { right: window.innerWidth - pos.x, top: pos.y } : { left: pos.x, top: pos.y }}
          onClick={() => setPos(null)}
        >
          {items.map((it, i) =>
            it === 'sep' ? (
              <hr key={i} />
            ) : (
              <button key={i} role="menuitem" disabled={it.disabled} onClick={it.onClick}>
                <Ic name={it.icon} />
                <span>{it.label}</span>
                {it.hint && <kbd>{it.hint}</kbd>}
              </button>
            ),
          )}
        </div>
      )}
    </>
  );
}

type Props = {
  theme: 'light' | 'dark';
  onTheme(): void;
  onProjects(): void;
  onAbout(): void;
  onExportVideo(): void;
  canPreview: boolean;
};

export function Toolbar({ theme, onTheme, onProjects, onAbout, onExportVideo, canPreview }: Props) {
  const plan = useStudio((s) => s.plan);
  const mode = useStudio((s) => s.mode);
  const canUndo = useStudio((s) => s.past.length > 0);
  const canRedo = useStudio((s) => s.future.length > 0);
  const status = useSaveStatus((s) => s.status);
  const tool = useStudio((s) => s.tool);
  const st = useStudio.getState();
  const fileRef = useRef<HTMLInputElement>(null);
  const [savingProject, setSavingProject] = useState<SaveProgress | null>(null);
  const pieces = pieceCount(plan);
  const editingModel = useStudio((s) => s.editingModel);
  const [regenerating, setRegenerating] = useState(false);
  /**
   * Plans the model being edited again: its build steps (undoable), its animation
   * (the saved one is discarded), or both.
   */
  const regenerate = async (what: 'both' | 'steps' | 'animation') => {
    if (regenerating) return;
    setRegenerating(true);
    try {
      const s = useStudio.getState();
      let next = s.plan;
      if (what !== 'animation') {
        registerInlineParts(next.parts);
        await ensureParts(allPartIds(next));
        next = regenerateSteps(next, s.editingModel, metricsOf, getColors());
        s.apply(() => next);
      }
      if (what !== 'steps') {
        await forgetTimelines(next, [s.editingModel], animOptions(useAppSettings.getState())).catch(() => {});
        s.replan();
      }
    } catch (e) {
      alert(`Couldn't regenerate:\n\n${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setRegenerating(false);
    }
  };

  const openProjectFile = async (f: File) => {
    const r = readProjectFile(await f.text());
    if (!r.ok) return alert(`Couldn't open ${f.name}:\n\n${r.errors.slice(0, 8).join('\n')}`);
    if (pieceCount() > 0 && !confirm('Replace the current set with this project? (You can undo.)')) return;
    const plan = ensureIds(r.plan);
    // Use the video settings the animations were planned with, or they would not match and be planned again.
    const main = r.timelines.find((t) => t.model === '') ?? r.timelines[0];
    const saved = main ? settingsFromOptsKey(main.opts) : null;
    if (saved) useAppSettings.getState().set(saved);
    const current = optsKey(animOptions(useAppSettings.getState()));
    // Store the planned timelines first, so the preview finds them instead of planning again.
    // A file saved by an older version keys its settings differently; also file it under today's key.
    await Promise.all(r.timelines.flatMap((t) => [t.opts, ...(saved && t.opts === main!.opts && t.opts !== current ? [current] : [])]
      .map((opts) => adoptTimeline(plan, t.model, opts, t.timeline).catch(() => {}))));
    st.setPlan(plan);
    st.setEditingModel('');
    if (r.skipped) alert(`${r.skipped} saved animation timeline(s) in ${f.name} were damaged and will be planned again.`);
  };
  const importFile = async (f: File) => {
    if (isProjectFile(f.name)) return openProjectFile(f);
    const r = readPlanFile(await f.text(), f.name);
    if (!r.ok) return alert(`Couldn't open ${f.name}:\n\n${r.errors.slice(0, 8).join('\n')}`);
    if (pieceCount() > 0 && !confirm('Replace the current set with this file? (You can undo.)')) return;
    let plan = ensureIds(r.plan);
    // LDraw files without STEP lines put hundreds of parts in one step. Give those
    // models bottom-up layer steps so the build reads like real instructions.
    if (modelsWithoutSteps(plan).length) {
      registerInlineParts(plan.parts);
      await ensureParts(allPartIds(plan));
      // big step-less models (a train) build their bogies and roof aside first
      plan = splitPlanComponents(plan, metricsOf, getColors()).plan;
      plan = autoStepPlan(plan, metricsOf, getColors()).plan;
    }
    st.setPlan(plan);
    st.setEditingModel('');
  };
  /** The whole set with every build animation (planned now if needed). */
  const downloadProject = () => saveProjectFile(plan, '', setSavingProject);
  const downloadPlan = () => saveBlob(`${safeFileName(plan.name)}.plan.json`, new Blob([planToJson(plan)], { type: 'application/json' }));
  const downloadLDraw = () => saveBlob(`${safeFileName(plan.name)}.mpd`, new Blob([exportLDraw(plan, metricsOf, getColors())], { type: 'text/plain' }));

  return (
    <header className="nx-head">
      <div className="nx-head-left">
        <span className="nx-brand">
          <span className="nx-brand-mark">
            <Ic name="brick" />
          </span>
          <span>BrickMotion</span>
        </span>
        <span className="nx-sep" />
        <DropMenu
          className="nx-file"
          label="Project menu"
          trigger={
            <>
              <Ic name="folder" /> Projects <Ic name="chevron" />
            </>
          }
          items={[
            { icon: 'plus', label: 'New project', onClick: () => void newProject() },
            { icon: 'folder', label: 'Open project…', onClick: onProjects },
            { icon: 'upload', label: 'Import file…', hint: `.${PROJECT_EXTENSION} .json .ldr .mpd .dat`, onClick: () => fileRef.current?.click() },
            'sep',
            { icon: 'download', label: savingProject ? `Planning animations to save (${savingProject.done + 1} of ${savingProject.total})…` : `Save project with animation (.${PROJECT_EXTENSION})`, disabled: pieces === 0 || !!savingProject, onClick: () => void downloadProject() },
            { icon: 'file', label: 'Download plan (.json)', onClick: downloadPlan },
            { icon: 'file', label: 'Download LDraw (.mpd)', onClick: downloadLDraw },
            'sep',
            { icon: 'info', label: 'About BrickMotion', onClick: onAbout },
          ]}
        />
        <input
          className="nx-title"
          value={plan.name}
          aria-label="Set name"
          placeholder="Untitled set"
          onChange={(e) => st.apply((p) => ({ ...p, name: e.target.value }))}
        />
        <input
          ref={fileRef}
          type="file"
          accept={`.${PROJECT_EXTENSION},.json,.ldr,.mpd,.dat`}
          hidden
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void importFile(f);
            e.target.value = '';
          }}
        />
      </div>
      <div className="bm-tools" role="radiogroup" aria-label="Tools">
        <button
          className={`nx-icon ${tool === 'select' ? 'on' : ''}`}
          role="radio"
          aria-checked={tool === 'select'}
          aria-label="Select tool"
          title="Select (V): click to select, drag to turn the view"
          onClick={() => st.setTool('select')}
        >
          <Ic name="pointer" />
        </button>
        <button
          className={`nx-icon ${tool === 'move' ? 'on' : ''}`}
          role="radio"
          aria-checked={tool === 'move'}
          aria-label="Move tool"
          title="Move (M): drag a piece to move it on the floor"
          onClick={() => st.setTool('move')}
        >
          <Ic name="move" />
        </button>
      </div>
      <div className="nx-head-right">
        <button className="nx-icon" onClick={st.undo} disabled={!canUndo} title="Undo (⌘Z)" aria-label="Undo">
          <Ic name="undo" />
        </button>
        <button className="nx-icon" onClick={st.redo} disabled={!canRedo} title="Redo (⇧⌘Z)" aria-label="Redo">
          <Ic name="redo" />
        </button>
        {savingProject && (
          <span className="nx-save dirty" role="status" title="The project file downloads once every animation is planned">
            <span className="nx-dot" />
            Planning animations for the project file ({savingProject.done + 1} of {savingProject.total})…
          </span>
        )}
        <span className={`nx-save ${status === 'saved' ? '' : status}`} title="Projects save in this browser">
          <span className="nx-dot" />
          {status === 'saved' ? 'Saved' : status === 'dirty' ? 'Saving…' : "Couldn't save"}
        </span>
        <button className="nx-icon" onClick={onTheme} title={theme === 'dark' ? 'Light theme' : 'Dark theme'} aria-label="Toggle theme">
          <Ic name={theme === 'dark' ? 'sun' : 'moon'} />
        </button>
        <DropMenu
          className="nx-btn"
          label="Regenerate"
          align="right"
          trigger={
            <>
              <Ic name="rotate" /> {regenerating ? 'Regenerating…' : 'Regenerate'} <Ic name="chevron" />
            </>
          }
          items={[
            { icon: 'rotate', label: `Steps and animation${editingModel ? ` of ${editingModel}` : ''}`, disabled: pieces === 0 || regenerating, onClick: () => void regenerate('both') },
            { icon: 'steps', label: 'Build steps only', disabled: pieces === 0 || regenerating, onClick: () => void regenerate('steps') },
            { icon: 'video', label: 'Animation only', disabled: pieces === 0 || regenerating, onClick: () => void regenerate('animation') },
          ]}
        />
        <button className="nx-btn" disabled={!canPreview} onClick={() => st.setMode(mode === 'edit' ? 'preview' : 'edit')}>
          <Ic name={mode === 'edit' ? 'eye' : 'edit'} /> {mode === 'edit' ? 'Preview' : 'Edit'}
        </button>
        <DropMenu
          className="nx-btn nx-primary"
          label="Export"
          align="right"
          trigger={
            <>
              <Ic name="download" /> Export <Ic name="chevron" />
            </>
          }
          items={[
            { icon: 'video', label: 'Video (MP4)…', disabled: pieces === 0, onClick: onExportVideo },
            'sep',
            { icon: 'download', label: savingProject ? `Planning animations to save (${savingProject.done + 1} of ${savingProject.total})…` : `Project with animation (.${PROJECT_EXTENSION})`, disabled: pieces === 0 || !!savingProject, onClick: () => void downloadProject() },
            { icon: 'file', label: 'Plan (.json)', onClick: downloadPlan },
            { icon: 'file', label: 'LDraw (.mpd)', onClick: downloadLDraw },
          ]}
        />
      </div>
    </header>
  );
}

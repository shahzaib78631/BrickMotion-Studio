import type { Box } from '../../ldraw/flatten';
import { add, sub, mul, norm, unit, dot, vector, axisDirections, shiftBox, union, size, sweptBox, overlaps, centre, rigidDelta, pos, point, multiply } from './math';
import type { V3, M4 } from './math';
import { fixedBayPose, isIdentityOrientation, oracleOffsets, poseMoved, poseWithCentreAndYaw, sameOrientation, stagedBounds, turningSphere, yawOf } from './rigidStaging';
import { discoverConnections } from './connections';
import { assemblyRole } from '../assemblyGraph';
import { MeshOracle, SKIN } from './collision';
import { certifiedMechanicalContact } from './mechanicalContacts';
import { buildMechanicalConstraintGraph, explainMissingMechanicalMate } from './mechanicalConstraintGraph';
import { mechanicalSubassemblies } from './subassemblies';
import { semanticComposites } from './semanticComposites';
import { recognizedGearMesh } from './meshingContacts';
import { REVIEWED_5590_SURFACES, verifyReviewedSurface } from './reviewedSurfaceContacts';
import { possibleFinalContacts } from './contactBroadphase';
import { ScopeSceneIndex } from './sceneIndex';
import { guidedDirections, nearDistances, farExits } from './nearFar';
import { mayReuseBlockedNearRay, type BlockedNearRay } from './routePruning';
import { findCertifiedDetour } from './configurationSpace';
import { authoredStepModules } from './stepModules';
import { isGeneratedWorkBay, workBayAnchorId, workBayKey, workBayKind, workBayLabel } from './workBays';
import { ConstructionError, type ConstructionModel, type ConstructionNode, type ConstructionPlan, type ConstructionOptions, type Blockage, type Operation, type SearchStats, type Connection, type WorkBay } from './types';
type Slot = {
    id: string;
    pose: M4;
    box: Box;
};
type Removal = {
    node: ConstructionNode;
    poses: M4[];
    connections: string[];
    support: Operation['check']['support'];
};
type RouteResult = { poses: M4[] };
const ZERO: V3 = [0, 0, 0], AXES: V3[] = [[0, -1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, 1, 0]];
const unique = (v: V3[]) => v.filter((d, i) => !v.slice(0, i).some(e => dot(d, e) > 1 - 1e-10));
const owns = (node: ConstructionNode, id: string): boolean => node.id === id || node.leaves.includes(id) || !!node.children?.some(n => owns(n, id));
const compactPoses = (poses: M4[]) => poses.filter((p, i) => !i || p.some((v, k) => Math.abs(v - poses[i - 1][k]) > 1e-9));
function positive(value: number | undefined, fallback: number, max: number): number { if (value === undefined)
    return fallback; if (!Number.isFinite(value) || value <= 0)
    throw new ConstructionError('invalid-input', 'Search budgets must be finite and positive.'); return Math.max(1, Math.min(max, Math.floor(value))); }
/** Backward removal search -> precomputed construction operations -> verified replay.
 * The planner never invokes legacy routing, never hides parts, and never relaxes
 * contact limits when a search budget is exhausted.
 */
export function planConstruction(model: ConstructionModel, options: ConstructionOptions = {}): ConstructionPlan {
    const start = performance.now(), stats: SearchStats = { states: 0, candidates: 0, backtracks: 0, meshPairs: 0, trianglePairs: 0, cacheHits: 0, milliseconds: 0, guidedCandidates: 0, exhaustiveCandidates: 0, broadphaseQueries: 0, broadphaseHits: 0, blockedNearRays: 0, avoidedNearDepthChecks: 0, directSkyAttempts: 0, directSkySuccesses: 0, cachedNearRayRejects: 0, deferredPreviouslyBlockedNodes: 0, boundedExhaustiveBranches: 0, configurationDetourAttempts: 0, configurationDetourSuccesses: 0, configurationDetourStates: 0, configurationDetourEdges: 0, engagedDetourAttempts: 0, engagedDetourSuccesses: 0 };
    const guided = options.algorithm === 'guided-v3';
    const maxStates = positive(options.maxStates, 2000, 100000), maxMilliseconds = positive(options.maxMilliseconds, 20000, 120000), maxCandidates = positive(options.maxCandidates, 100000, 2000000);
    let scope = '', phase: NonNullable<ConstructionError['details']['phase']> = 'connections', lastBlockages: Blockage[] = [];
    const pulse = () => {
        stats.milliseconds = Math.round(performance.now() - start);
        if (options.cancelled?.())
            throw new ConstructionError('cancelled', 'Construction planning was cancelled.', { scope, phase, stats: { ...stats } });
        if (stats.milliseconds > maxMilliseconds || stats.states > maxStates || stats.candidates > maxCandidates)
            throw new ConstructionError('search-budget-exhausted', 'The bounded search did not finish. This does not establish physical impossibility.', { scope, phase, blockages: lastBlockages.slice(-12), stats: { ...stats } });
    };
    options.onProgress?.({ phase: 'connections', completed: 0, total: model.parts.size });
    const graph = discoverConnections(model), ground = model.bounds.max[1];
    pulse();
    // Classify genuine profiled connections before selecting physical workbench
    // modules. This graph is also reused by the later final-contact audit.
    const mechanicalGraph = guided ? buildMechanicalConstraintGraph(model, pulse) : undefined;
    stats.mechanicalJointHints = mechanicalGraph?.joints.length ?? 0;
    stats.articulatedJointHints = mechanicalGraph?.joints.filter(j => j.motion === 'revolute' || j.motion === 'ball').length ?? 0;
    const mechanicallyGrouped = options.mechanicalSubassemblies === false ? model.nodes : mechanicalSubassemblies(model.nodes, graph.connections, graph.dependencies);
    // Preserve V3's existing declared hard-module grouping. Newly inferred
    // static-only joints guide only authored-step modules and route proposals.
    if (mechanicalGraph) graph.connections.push(...mechanicalGraph.connections);
    const stepModules = guided && options.enableStepModules === true
        ? authoredStepModules(mechanicallyGrouped, mechanicalGraph?.connections ?? [], graph.dependencies)
        : { nodes: mechanicallyGrouped, modules: 0, members: 0 };
    const composite = semanticComposites(stepModules.nodes, model.metrics);
    const rootNodes = composite.nodes;
    stats.authoredStepModules = stepModules.modules;
    stats.authoredStepModuleMembers = stepModules.members;
    // These are one pre-shaped part, not already-assembled independent bricks.
    // Keep each rendered segment in the model/animation, but make one atomic
    // stage/flight. All external collisions still use every original triangle.
    const compositeOwners = new Map<string, string>();
    const locateComposites = (nodes: ConstructionNode[]) => nodes.forEach(n => {
        if (n.atomic) n.leaves.forEach(key => compositeOwners.set(key, n.id));
        else if (n.children) locateComposites(n.children);
    });
    locateComposites(rootNodes);
    const all: ConstructionNode[] = [];
    const collect = (nodes: ConstructionNode[]) => nodes.forEach(n => { all.push(n); if (n.children && !n.atomic)
        collect(n.children); });
    collect(rootNodes);
    const slots = new Map<string, Slot>(), gap = 24;
    // A bay is a held subassembly, so it may float only when one of its own
    // children must withdraw along a downward anatomical axis. Posed hands are
    // the common case. Lift by exactly the first connector-scale withdrawal
    // depth; unrelated bays (heads, hats, hips) keep resting on the table.
    // Loose leaves are always staged on the table.
    const benchLift = (n: ConstructionNode): number => {
        if (!n.children?.length) return 0;
        let lift = 0;
        for (const c of graph.connections) {
            if (c.kind !== 'anatomical' || !c.outward || c.outward[1] <= 0) continue;
            const child = n.children.find(d => owns(d, c.child));
            const parent = n.children.find(d => owns(d, c.parent));
            if (!child || !parent || child === parent) continue;
            const lengths = [...(c.region ? [c.region.length] : []), ...(c.regions ?? []).map(r => r.length)];
            const connector = lengths.length ? Math.max(...lengths) + 0.1 : 0;
            lift = Math.max(lift, (connector ? Math.max(connector, 2.05) : 4.05) * c.outward[1] + 0.05);
        }
        return lift;
    };
    // Group work bays and loose-part inventory are two different resources.
    // Packing them into one row made the first part removed from a nested group
    // become a *real* obstacle beside that same group's workbench. A second arm,
    // hand or leg could then be blocked by staging furniture that existed only
    // because of our layout choice. Keep group bays in one zone and every
    // individually staged leaf in a separate inventory zone. Both zones remain
    // visible and physical once occupied; only their abstract empty boxes are
    // non-obstacles.
    const groupNodes = all.filter(n => !!n.children?.length && !n.atomic), leafNodes = all.filter(n => !n.children?.length || !!n.atomic);
    // A chosen build spot fixes a group bay. The automatic bays are laid out around it,
    // and it never moves because another spot moved.
    const layoutModel = options.layoutBounds ?? model.bounds;
    for (const n of groupNodes) {
        // An authored submodel spot wins over a saved generated-bay placement.
        const authored = n.hints?.buildSpot;
        const override = isGeneratedWorkBay(n.id) ? options.workBaySpots?.[n.id] : undefined;
        const spot = authored ?? override;
        if (!spot)
            continue;
        // Manual bays are global positions and orientations. Never shift or turn
        // a chosen bay just because its parent assembly is itself rotated. The
        // fixture clearance keeps downward anatomical withdrawals above the
        // table exactly as it does for automatic bays.
        if (![spot.x, spot.z, spot.angle].every(Number.isFinite))
            throw new ConstructionError('invalid-input', `Invalid coordinates or angle on the work bay for ${n.id}.`, { items: [n.id] });
        const pose = poseMoved(fixedBayPose(n.bounds, spot, ground), [0, -benchLift(n), 0]);
        slots.set(n.id, { id: n.id, pose, box: stagedBounds(n.bounds, pose) });
    }
    const pack = (nodes: ConstructionNode[], originX: number, clearance: (n: ConstructionNode) => number = () => 0): number => {
        if (!nodes.length) return originX;
        const area = nodes.reduce((s, n) => s + (size(n.bounds)[0] + gap) * (size(n.bounds)[2] + gap), 0);
        const rowWidth = Math.max(240, Math.sqrt(area) * 1.25, ...nodes.map(n => size(n.bounds)[0] + gap));
        const originZ = layoutModel.min[2];
        let x = originX, z = originZ, rowDepth = 0, maxX = originX;
        for (const n of nodes) {
            if (slots.has(n.id))
                continue;
            const d = size(n.bounds);
            if (x > originX && x + d[0] > originX + rowWidth) {
                x = originX;
                z += rowDepth + gap;
                rowDepth = 0;
            }
            const offset: V3 = [x - n.bounds.min[0], ground - n.bounds.max[1] - clearance(n), z - n.bounds.min[2]];
            const box = shiftBox(n.bounds, offset);
            slots.set(n.id, { id: n.id, pose: rigidDelta(offset), box });
            maxX = Math.max(maxX, box.max[0]);
            x += d[0] + gap;
            rowDepth = Math.max(rowDepth, d[2]);
        }
        return maxX;
    };
    const workOriginX = Math.max(layoutModel.max[0] + gap, ...[...slots.values()].map(s => s.box.max[0] + gap));
    const workMaxX = pack(groupNodes, workOriginX, benchLift);
    // Two gaps provide a clear transport aisle between active workbenches and
    // stored loose pieces. The continuous scene replay still checks every real
    // staged mesh, so this is spatial planning rather than a collision bypass.
    pack(leafNodes, Math.max(workOriginX, workMaxX + 2 * gap));
    for (const node of leafNodes) if (node.atomic) {
        const staged = slots.get(node.id)!;
        for (const key of node.leaves) slots.set(key, staged);
    }
    // Report every generated bay to the editor. Labels stay deterministic even
    // when two uses of the same submodel produce identical kind/part pairs.
    const generatedGroups = groupNodes.filter(n => isGeneratedWorkBay(n.id));
    const baseLabels = new Map<string, string>(), labelTotals = new Map<string, number>();
    for (const n of generatedGroups) {
        const label = workBayLabel(n.id, model.parts.get(workBayAnchorId(n.id))?.part);
        baseLabels.set(n.id, label);
        labelTotals.set(label, (labelTotals.get(label) ?? 0) + 1);
    }
    const labelSeen = new Map<string, number>(), workBays: WorkBay[] = [];
    const tidy = (value: number): number => { const rounded = Math.round(value * 1e6) / 1e6; return Object.is(rounded, -0) ? 0 : rounded; };
    for (const n of generatedGroups) {
        const slot = slots.get(n.id);
        if (!slot)
            continue;
        const base = baseLabels.get(n.id)!, duplicates = labelTotals.get(base)!;
        const seen = (labelSeen.get(base) ?? 0) + 1;
        labelSeen.set(base, seen);
        const override = options.workBaySpots?.[n.id];
        const auto = {
            x: tidy((slot.box.min[0] + slot.box.max[0]) / 40),
            z: tidy((slot.box.min[2] + slot.box.max[2]) / 40),
            angle: tidy(yawOf(slot.pose) * 180 / Math.PI),
        };
        workBays.push({
            id: n.id,
            key: workBayKey(n.id),
            kind: workBayKind(n.id)!,
            label: duplicates > 1 ? `${base} ${seen}` : base,
            model: n.model,
            parts: [...new Set(n.leaves.map(key => model.parts.get(key)?.part).filter((part): part is string => !!part))],
            spot: override ? { ...override } : auto,
            placed: !!override,
        });
    }
    // Work areas are planning coordinates, not physical obstacles. A group bay
    // is empty until that subassembly is actually moved there. Treating every
    // work area as solid made nested scopes (for example $upper/$lower minifig
    // modules) block one another even though no geometry occupied those boxes.
    // Physical staged obstacles are tracked dynamically from already-removed
    // nodes below and checked with their real leaf meshes.
    const workAreas = new Map<string, Slot>([['$root', { id: '$root', pose: rigidDelta(ZERO), box: model.bounds }], ...slots]);
    const layoutAreas = [...workAreas.values()];
    const sceneBounds = layoutAreas.map(s => s.box).reduce(union, model.bounds);
    const ceiling = Math.min(...layoutAreas.map(s => s.box.min[1])) - 32;
    const oracle = new MeshOracle(model, stats, pulse);
    // Joint metadata is planning topology, not a collision certificate.
    pulse();
    const hasContactPolicy = (c: Connection) => !!(c.region || c.regions?.length || c.surfaceTolerance);
    const hasMotionPolicy = (c: Connection) => hasContactPolicy(c) && !c.staticOnly;
    // Collision checks may consult contact policies millions of times. A
    // per-pair map avoids repeatedly scanning every model connection for each
    // leaf-vs-leaf swept test. Keep it updated as the final-contact audit adds
    // narrow static-only certificates.
    const directed = (a: string, b: string) => `${a.length}:${a}${b.length}:${b}`;
    const policyIndex = new Map<string, Connection[]>();
    const register = (c: Connection) => {
        const key = directed(c.child, c.parent);
        const list = policyIndex.get(key) ?? [];
        list.push(c);
        policyIndex.set(key, list);
    };
    graph.connections.forEach(register);
    const addPolicy = (c: Connection) => { graph.connections.push(c); register(c); };
    const staticPolicyFor = (a: string, b: string) => (policyIndex.get(directed(a, b)) ?? []).find(hasContactPolicy);
    const motionPoliciesFor = (a: string, b: string) => (policyIndex.get(directed(a, b)) ?? []).filter(hasMotionPolicy);
    const clearWithPolicies = (a: string, b: string, from: V3, offset: V3, delta: V3) => {
        const policies = motionPoliciesFor(a, b);
        return policies.length ? policies.some(p => oracle.clear(a, b, from, offset, delta, p)) : oracle.clear(a, b, from, offset, delta);
    };
    const nodeRole = (n: ConstructionNode) => n.hints?.role ?? assemblyRole(n.part);
    // Posed hands and legs in authored scenes can intentionally touch seats,
    // controls or vehicle bodywork without being mechanically attached to those
    // parts.  Legacy LDraw render meshes often overlap such a touch by roughly
    // one stud-height because studs, hollow soles and rounded hand geometry are
    // not watertight collision solids.  Keep this allowance final-pose-only,
    // directional and restricted to hand/leg versus non-anatomical scene parts.
    // It never applies to generic brick/brick overlap or to containment.
    const poseSurfaceLimit = (moving: ConstructionNode, obstacle: ConstructionNode): number | undefined => {
        const r = nodeRole(moving), other = nodeRole(obstacle);
        if (other !== 'generic') return;
        // Nested authored figures inside vehicles/scenery are a separate final-
        // pose concern from mechanical attachment. Legacy render meshes include
        // studs, hair shells and rounded hands that can overlap neighbouring
        // vehicle detail substantially even though no connector exists between
        // them. These bounds are used ONLY by staticContact(); any certificate
        // it creates is staticOnly and therefore cannot weaken route collision
        // checks. Large hand bounds intentionally expose such poses to the later
        // articulation/motion stage rather than pretending they are rigid joints.
        if (r === 'hand') return 16.05;
        if (r === 'headwear') return 8.05;
        if (r === 'head' || r === 'leg') return 4.05;
        return;
    };
    // Very thin, studless geometry is commonly a sticker/decal surface rather
    // than a closed solid.  It may be certified only by separating it along its
    // own thin normal by no more than its measured thickness plus a small skin.
    // This remains pair-specific and never exempts the surface from other parts.
    const thinSurface = (n: ConstructionNode): { axis: V3; thickness: number } | undefined => {
        if (!n.part) return;
        const m = model.metrics(n.part), d = size(m.full);
        let k = 0;
        if (d[1] < d[k]) k = 1;
        if (d[2] < d[k]) k = 2;
        const other = [0, 1, 2].filter(i => i !== k);
        if (d[k] > 3.1 || other.some(i => d[i] < 16) || m.studs?.length || m.socketFace) return;
        const basis: V3[] = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
        return { axis: unit(vector(n.matrix, basis[k])), thickness: d[k] };
    };
    phase = 'final-contact-audit';
    const auditStarted = performance.now();
    scope = '$root';
    // Audit the supplied completed placement before spending a search budget on
    // access routes. Unmodelled mesh contact is NOT declared physically invalid.
    const finalContacts: Blockage[] = [], contactWarnings: string[] = [], leaves = [...model.parts.values()];
    let certifiedSurfaceContacts = 0, certifiedMechanicalContacts = 0, recognizedGearContacts = 0, reviewedSurfaceContacts = 0;
    const reviewed = [...(options.disableBundledSurfaceReviews ? [] : REVIEWED_5590_SURFACES), ...(options.reviewedSurfaces ?? [])];
    const reviewedByPair = new Map<string, typeof reviewed>();
    for (const review of reviewed) {
        const key = directed(review.moving, review.obstacle);
        const list = reviewedByPair.get(key) ?? [];
        list.push(review); reviewedByPair.set(key, list);
    }
    audit: for (const [a, b] of possibleFinalContacts(leaves)) {
            pulse();
            if (compositeOwners.has(a.id) && compositeOwners.get(a.id) === compositeOwners.get(b.id)) continue;
            const ab = staticPolicyFor(a.id, b.id), ba = staticPolicyFor(b.id, a.id);
            const ta = thinSurface(a), tb = thinSurface(b);
            const ra = nodeRole(a), rb = nodeRole(b);
            // A known directed connector decides the moving side. Without one,
            // prefer a single thin surface as the moving decoration. For authored
            // pose contact, move the anatomical hand/leg rather than the vehicle
            // or scenery it is touching so the resulting surface policy has the
            // physically meaningful withdrawal side.
            const poseRoles = ['hand', 'leg', 'head', 'headwear'];
            const posedA = poseRoles.includes(ra) && rb === 'generic';
            const posedB = poseRoles.includes(rb) && ra === 'generic';
            // Both directions can carry a contact policy (for example an
            // anatomical hip joint and a static-only mechanical profile). The
            // hard, non-static joint must decide the moving side; otherwise the
            // chosen direction depends on broad-phase pair order and a profile
            // region can be asked to explain geometry it never covered.
            const hard = (c?: Connection) => !!c && !c.staticOnly;
            const moving = hard(ab) && !hard(ba) ? a : hard(ba) && !hard(ab) ? b
                : ba ? b : ab ? a : ta && !tb ? a : tb && !ta ? b : posedA ? a : posedB ? b : a;
            const obstacle = moving === a ? b : a, policy = moving === a ? ab : ba;
            const thin = moving === a ? ta : tb;
            const poseProbe = !policy && !thin ? poseSurfaceLimit(moving, obstacle) : undefined;
            // Stud connections in legacy LDraw scenes can carry small pose
            // quantisation across a long plate/hinge chain. Probe a larger
            // separation only for an already-recognised stud pair. A thin
            // decoration gets only its own measured thickness along its normal.
            // Posed hand/leg touches get at most one stud-height, never a global
            // collision tolerance and never a containment exemption.
            // An explicit policy's tolerance is a measured certification bound,
            // not merely a minimum. Probing farther can leave a shallow clear
            // window and hit unrelated geometry on the far side, falsely turning
            // a valid surface certificate back into an unresolved contact.
            const contactProbe = policy?.surfaceTolerance ?? (policy?.kind === 'stud' ? 6.0 : thin ? Math.max(2.0, thin.thickness + .25) : poseProbe ?? 2.0);
            const probePolicy = policy ?? (thin ? { id: '$thin-probe', parent: obstacle.id, child: moving.id, kind: 'surface' as const, confidence: 'inferred' as const, outward: thin.axis } : undefined);
            const relation = oracle.staticContact(moving.id, obstacle.id, probePolicy, contactProbe);
            if (relation.kind === 'clear' || relation.kind === 'connector')
                continue;
            if (relation.kind === 'surface' && relation.separation && norm(relation.separation) <= contactProbe + SKIN) {
                let distance = norm(relation.separation), outward = unit(relation.separation), staticOnly = true;
                // A recognised connector may have a tiny residual overlap with a
                // neighbouring, non-connected render shell (helmet beside a
                // backpack is a common example). If moving the connector child
                // straight along its *already verified* withdrawal axis reaches
                // a collision-free pose within a very small bound, certify only
                // that initial separating motion for this exact pair. This is
                // stronger than a generic final-pose surface certificate but far
                // narrower than a collision tolerance: it is directional,
                // pair-specific, capped at 4.05 LDU and the remainder of the
                // swept route is still checked with ordinary collision rules.
                const connectorDirs = graph.connections
                    .filter(c => c.child === moving.id && c.kind !== 'surface' && !c.staticOnly && c.outward)
                    .map(c => unit(c.outward!));
                let guided: { distance: number; outward: V3 } | undefined;
                for (const dir of connectorDirs) {
                    const limit = 4.05, samples = 16;
                    let lo = 0, hi: number | undefined;
                    for (let i = 1; i <= samples; i++) {
                        const d = limit * i / samples;
                        if (oracle.clear(moving.id, obstacle.id, mul(dir, d), ZERO, ZERO, policy)) {
                            hi = d;
                            break;
                        }
                        lo = d;
                    }
                    if (hi === undefined) continue;
                    let upper: number = hi;
                    for (let i = 0; i < 8; i++) {
                        const mid = (lo + upper) / 2;
                        if (oracle.clear(moving.id, obstacle.id, mul(dir, mid), ZERO, ZERO, policy)) upper = mid; else lo = mid;
                    }
                    const d = Math.min(limit, upper + SKIN);
                    if (!guided || d < guided.distance) guided = { distance: d, outward: dir };
                }
                if (guided) {
                    distance = guided.distance;
                    outward = guided.outward;
                    staticOnly = false;
                }
                // Thin surfaces are allowed to peel only along their own normal.
                // A sideways escape is ordinary collision avoidance, not evidence
                // that the final overlap is a sticker/decal attachment.
                if (thin && Math.abs(dot(outward, thin.axis)) < .999) {
                    finalContacts.push({ moving: moving.id, obstacle: obstacle.id, stage: 'final-placement', detail: `Thin-surface contact between ${moving.part} and ${obstacle.part} does not separate along the surface normal; connector metadata or the final placement is still required.` });
                    if (finalContacts.length >= 12) break audit;
                    continue;
                }
                if (distance > SKIN) {
                    // Final-pose residual contact is evidence about the completed
                    // model, not permission to skip the same distance during an
                    // animated insertion. Keep it in a separate static-only
                    // certificate even when a real connector also exists.
                    const id = 'surface:' + JSON.stringify([obstacle.id, moving.id, outward.map(v => Math.round(v * 1e6) / 1e6)]);
                    if (!graph.connections.some(c => c.id === id))
                        // The guided separation above was certified through the
                        // original connector's localized material. Keep those
                        // regions on the motion certificate so the route oracle
                        // can reproduce exactly the same checked contact; the
                        // generic surfaceTolerance is never a blind skip.
                        addPolicy({ id, parent: obstacle.id, child: moving.id, kind: 'surface', confidence: 'inferred', outward, surfaceTolerance: distance, staticOnly,
                            region: policy?.region, regions: policy?.regions,
                            ...(staticOnly ? {} : { surfaceAnchor: sub(pos(moving.matrix), pos(obstacle.matrix)) })});
                    certifiedSurfaceContacts++;
                }
                continue;
            }
            // Resolve otherwise unexplained completed-pose mechanical joints
            // using LDCad cylinders AND the exact static triangle/containment
            // oracle. This does not waive any insertion, extraction or flight.
            // Reuse the directed contact-policy index. Filtering the entire
            // mechanical topology for every touched pair is quadratic in the
            // number of nearby connector proposals on large Technic models.
            const candidates = mechanicalGraph ? [
                ...(policyIndex.get(directed(moving.id, obstacle.id)) ?? []),
                ...(policyIndex.get(directed(obstacle.id, moving.id)) ?? []),
            ].filter(c => c.id.startsWith('profiled:') && c.staticOnly) : [];
            const mechanical = candidates.find(c =>
                oracle.clear(c.child, c.parent, ZERO, ZERO, ZERO, c))
                ?? certifiedMechanicalContact(model, moving, obstacle, oracle)
                ?? certifiedMechanicalContact(model, obstacle, moving, oracle);
            if (mechanical) {
                addPolicy(mechanical);
                certifiedMechanicalContacts++;
                continue;
            }
            // Pose-bound, human-reviewed surface witnesses are separate from
            // joints. Their exact relative transforms and live geometry must
            // match; neither a part-number pair nor a generic 2.1 LDU threshold
            // can grant this certificate. No insertion or transport exemptions.
            const reviewedCandidates = [
                ...(reviewedByPair.get(directed(a.id, b.id)) ?? []),
                ...(reviewedByPair.get(directed(b.id, a.id)) ?? []),
            ];
            const reviewedContact = reviewedCandidates.map(r => verifyReviewedSurface(model, r, oracle)).find(Boolean);
            if (reviewedContact) {
                addPolicy(reviewedContact);
                reviewedSurfaceContacts++;
                continue;
            }
            // Gear teeth are intentionally engaged at final pose in many LDraw
            // models. Classify only a measured, shallow, non-contained mesh
            // between explicitly described gear parts. Never allow an unchecked
            // arrival or departure: this certificate is static-only.
            const meshing = recognizedGearMesh(model, moving, obstacle, oracle);
            if (meshing) {
                addPolicy(meshing);
                recognizedGearContacts++;
                continue;
            }
            const reason = relation.kind === 'penetration'
                ? 'representative geometry is contained inside the other part'
                : `the contact persists beyond the bounded ${contactProbe.toFixed(1)} LDU ${policy?.kind === 'stud' ? 'stud-residual' : 'render-surface'} probe`;
            const connectorDiagnosis = mechanicalGraph ? ` ${explainMissingMechanicalMate(a, b, mechanicalGraph)}` : '';
            const witness = relation.failure as { contactPolygon?: V3[]; point?: V3 } | undefined;
            const contactPoint = witness?.contactPolygon?.[0] ?? witness?.point;
            const position = contactPoint?.every(Number.isFinite)
                ? ` Mesh witness near (${contactPoint.map(x => x.toFixed(2)).join(', ')}) LDU.` : '';
            finalContacts.push({ moving: a.id, obstacle: b.id, stage: 'final-placement',
                detail: `Final mesh contact between ${a.part} and ${b.part} is unresolved: ${reason}.${connectorDiagnosis}${position} Access order cannot certify it.`,
                ...(position ? { contactPoint } : {}) });
            if (finalContacts.length >= 12)
                break audit;
        }
    if (mechanicalGraph?.joints.length) contactWarnings.push(`The LDCad constraint graph identified ${mechanicalGraph.joints.length} typed mechanical interface(s) across ${mechanicalGraph.pairsExamined} close part pairs. These are planning hints; only separately checked mesh contacts and swept paths can receive collision certification.`);
    if (recognizedGearContacts) contactWarnings.push(`${recognizedGearContacts} shallow final-pose gear-tooth mesh contacts were recognized from part descriptions and measured separation. These are not route certificates: each insertion still requires strict swept-mesh verification. Gear articulation is not simulated.`);
    if (certifiedMechanicalContacts)
        contactWarnings.push(`${certifiedMechanicalContacts} previously unresolved completed-pose contacts match localized LDCad mechanical cylinders. The corresponding certifications are final-pose-only and do not relax animation route checks.`);
    if (reviewedSurfaceContacts) contactWarnings.push(`${reviewedSurfaceContacts} exact-relative-pose reviewed surface contact(s) passed re-measurement against the supplied meshes. They are static-only, not mechanical joints or collision-free insertion certificates.`);
    if (certifiedSurfaceContacts)
        contactWarnings.push(`${certifiedSurfaceContacts} final-pose contacts were classified as bounded directional surface contact. Recognised stud residuals may use up to 6.0 LDU; thin decorations are bounded by their measured thickness; authored anatomical scene contacts use role-specific final-pose bounds (hand 16.05, headwear 8.05, head/leg 4.05 LDU); other unrecognised contacts remain <= 2.0 LDU. These inferred surface certificates are static-only: assembly paths still undergo continuous collision checks and none create part-wide motion tolerances.`);
    stats.contactAuditMilliseconds = Math.round(performance.now() - auditStarted);
    if (!finalContacts.length) options.onContactAuditComplete?.({ reviewedSurfaceContacts, contactAuditMilliseconds: stats.contactAuditMilliseconds });
    if (finalContacts.length) {
        const partsOf = (b: Blockage) => [model.parts.get(b.moving)?.part, model.parts.get(b.obstacle)?.part]
            .map(p => p?.toLowerCase().replace(/\.dat$/, '') ?? '');
        const flexible = finalContacts.some(b => partsOf(b).some(p => p === '755' || p === '756'));
        const meshing = finalContacts.some(b => partsOf(b).every(p => ['3647', '3743', '4143'].includes(p)));
        const note = [
            flexible ? 'This model includes overlapping 755/756 flexible-hose segments; these are not independent rigid brick joints and must be treated as one flex/composite element before a rigid route can be certified.' : '',
            meshing ? 'Some gear/rack or gear/gear contacts are also unresolved; their mesh engagement needs connector-specific handling rather than a general collision exemption.' : '',
        ].filter(Boolean).join(' ');
        throw new ConstructionError('unresolved-final-contact',
            'The completed model contains contacts that remain unexplained after connector and bounded surface-contact classification. ' +
            (note || 'Check connector metadata or the final placement; changing access order alone cannot certify them.'),
            { scope: '$root', blockages: finalContacts, stats: { ...stats } });
    }
    stats.contactAuditMilliseconds = Math.round(performance.now() - auditStarted);
    let activeRouteWitnesses: Set<string> | undefined;
    const remember = (b: Blockage) => { activeRouteWitnesses?.add(b.obstacle); if (!lastBlockages.some(x => x.moving === b.moving && x.obstacle === b.obstacle && x.stage === b.stage))
        lastBlockages.push(b); if (lastBlockages.length > 64)
        lastBlockages.shift(); };
    type StagedObstacle = { node: ConstructionNode; pose: M4 };
    // A pair with the same world-rigid orientation can use the original exact
    // triangle oracle in their shared (unrotated) frame. For different bay
    // orientations we reject any possibly intersecting swept AABBs; accepting
    // such a pair without a rigid-vs-rigid mesh certificate would be unsafe.
    const clearSweep = (a: string, b: string, from: M4, to: M4, obstacle: M4, withPolicy: boolean): boolean => {
        const delta = sub(pos(to), pos(from));
        const ma = model.parts.get(a)!, mb = model.parts.get(b)!;
        if (!sweptBox(stagedBounds(ma.bounds, from), stagedBounds(mb.bounds, obstacle), delta, -1e-6))
            return true;
        if (!sameOrientation(from, to)) return false;
        if (!sameOrientation(from, obstacle)) {
            const policies = withPolicy ? motionPoliciesFor(a, b) : [];
            return policies.length
                ? policies.some(p => oracle.clearPosed(a, b, from, obstacle, delta, p))
                : oracle.clearPosed(a, b, from, obstacle, delta);
        }
        const local = oracleOffsets(from, obstacle, delta);
        return withPolicy
            ? clearWithPolicies(a, b, local.a, local.b, local.delta)
            : oracle.clear(a, b, local.a, local.b, local.delta);
    };
    // A V3 withdrawal failure has a concrete obstacle witness. Until that
    // obstacle leaves its exact scope position, no longer sweep along the SAME
    // ray can be certified. This is a reusable NEGATIVE certificate only; it
    // never claims any unchecked movement is clear.
    const nearRayBlocks = new Map<string, BlockedNearRay>();
    let firstSegmentBlocker: { id: string; staged: boolean } | undefined;
    const rememberSweep = (moving: ConstructionNode, obstacle: ConstructionNode, stage: Blockage['stage']) => {
        remember({ moving: moving.id, obstacle: obstacle.id, stage,
            detail: 'Continuous triangle-mesh collision detected along the swept translation segment.' });
    };
    // The scene index is immutable for a search state. Every reported possible
    // obstacle is still sent to the EXACT same MeshOracle as Construction V2.
    // A conservative broad phase is never treated as a clearance certificate.
    const segmentClear = (node: ConstructionNode, from: M4, to: M4, remaining: ConstructionNode[], staged: StagedObstacle[], scopePose: M4, first: boolean, index?: ScopeSceneIndex): boolean => {
        pulse();
        if (!sameOrientation(from, to))
            throw new ConstructionError('invalid-input', 'A translation segment cannot change its rigid orientation.');
        const delta = sub(pos(to), pos(from));
        if (norm(delta) < 1e-10) return true;
        const at = stagedBounds(node.bounds, from), end = stagedBounds(node.bounds, to);
        if (at.max[1] > ground + SKIN || end.max[1] > ground + SKIN) {
            if (first) firstSegmentBlocker = { id: 'floor', staged: false };
            remember({ moving: node.id, obstacle: 'floor', stage: 'floor', detail: 'A swept endpoint lies below the table.' });
            return false;
        }
        const possible = index
            ? index.swept(at, delta, node.id).map(hit => ({ node: hit.node, pose: hit.pose, staged: hit.staged }))
            : [...staged.map(hit => ({ ...hit, staged: true })), ...remaining.map(other => ({ node: other, pose: scopePose, staged: false }))]
                .filter(hit => hit.node !== node && sweptBox(at, stagedBounds(hit.node.bounds, hit.pose), delta, -1e-6));
        if (index) { stats.broadphaseQueries!++; stats.broadphaseHits! += possible.length; }
        for (const other of possible) {
            for (const a of node.leaves) for (const b of other.node.leaves) {
                if (!clearSweep(a, b, from, to, other.pose, first && !other.staged)) {
                    if (first) firstSegmentBlocker = { id: other.node.id, staged: other.staged };
                    rememberSweep(node, other.node, other.staged ? 'transport' : first ? 'withdrawal' : 'transport');
                    return false;
                }
            }
        }
        return true;
    };
    /** A rotation can only be made at a stationary world-space centre and when
     * the enclosing sphere is free. This is a continuous proof for ANY yaw,
     * including arbitrary 15/30/45-degree facing angles, not sampled frames. */
    const rotationEnvelopeClear = (node: ConstructionNode, from: M4, to: M4, remaining: ConstructionNode[], staged: StagedObstacle[], scopePose: M4, index?: ScopeSceneIndex): boolean => {
        pulse();
        const before = point(from, centre(node.bounds)), after = point(to, centre(node.bounds));
        if (norm(sub(before, after)) > 1e-6) return false;
        const envelope = turningSphere(node.bounds, from);
        if (envelope.max[1] > ground + SKIN) {
            remember({ moving: node.id, obstacle: 'floor', stage: 'floor', detail: 'The conservative rotation envelope crosses the table.' });
            return false;
        }
        const possible = index
            ? index.touching(envelope, node.id).map(hit => ({ node: hit.node, staged: hit.staged }))
            : [...staged.map(hit => ({ node: hit.node, staged: true })), ...remaining.map(node => ({ node, staged: false }))]
                .filter(hit => hit.node !== node && overlaps(envelope, stagedBounds(hit.node.bounds, hit.staged ? staged.find(p => p.node === hit.node)!.pose : scopePose)));
        for (const other of possible) {
            remember({ moving: node.id, obstacle: other.node.id, stage: 'transport', detail: other.staged
                ? 'Continuous rotation envelope intersects an occupied staging part.'
                : 'Continuous rotation envelope intersects assembled geometry.' });
            return false;
        }
        return true;
    };
    const support = (node: ConstructionNode, remaining: ConstructionNode[], pose: M4): Removal['support'] | null => {
        if (Math.abs(stagedBounds(node.bounds, pose).max[1] - ground) <= SKIN) return 'table';
        if (graph.connections.some(c => c.kind !== 'surface' && !c.staticOnly && ((owns(node, c.child) && remaining.some(n => owns(n, c.parent))) || (owns(node, c.parent) && remaining.some(n => owns(n, c.child))))))
            return 'connected';
        return options.supportMode === 'table' ? null : 'virtual-fixture';
    };
    const route = (node: ConstructionNode, remaining: ConstructionNode[], staged: StagedObstacle[], scopePose: M4, scopeId: string, index?: ScopeSceneIndex, allowExhaustive = true, connected: Connection[] = [], mayDetour = false): RouteResult | null => {
        const target = slots.get(node.id)!.pose;
        // If a manually placed submodel bay already coincides with its installed
        // pose, its children assemble in place. There is no group carry flight,
        // no clearance corridor to certify and no reason to lift it off its studs.
        // Require the full matrix (including height and rotation) to match:
        // matching just the floor X/Z footprint would be unsafe.
        if (node.children?.length && node.hints?.buildSpot &&
            scopePose.every((v, k) => Math.abs(v - target[k]) < 1e-6))
            return { poses: [scopePose, target] };
        const preferred = connected.flatMap(c => c.outward ? (c.axial ? [c.outward, mul(c.outward, -1)] : [c.outward]) : []);
        const directions = node.hints?.insertionAxis ? [unit(node.hints.insertionAxis)] : unique([...preferred, ...AXES, ...axisDirections(node.matrix)]);
        const anatomical = connected.filter(c => c.kind === 'anatomical' && c.outward);
        const dirs = (anatomical.length ? directions.filter(d => anatomical.every(c => dot(d, c.outward!) > .9999)) : directions)
            .map(d => unit(vector(scopePose, d)));
        const extent = Math.max(...size(node.bounds)), distances = [...new Set([2, 4, 8, 16, 32, Math.max(48, extent + 8)])];
        const work = workAreas.get(scopeId)!.box;
        const rotatedBay = !sameOrientation(scopePose, target);
        const radius = norm(mul(size(node.bounds), .5));
        // V3 NEAR/FAR: the small and meaningful search is run BEFORE V2's
        // combinatorial fallback. It produces no certificates itself; every
        // step uses the exact segment/turn validators and forward replay.
        let detourSeed: { entry: M4; finish: (at: M4) => RouteResult | null } | undefined;
        if (guided) {
            const transformed = stagedBounds(node.bounds, scopePose);
            const remainingBoxes = remaining.filter(n => n !== node).map(n => stagedBounds(n.bounds, scopePose));
            const movingNode: ConstructionNode = { ...node, bounds: transformed,
                hints: node.hints?.insertionAxis ? { ...node.hints, insertionAxis: unit(vector(scopePose, node.hints.insertionAxis)) } : node.hints };
            const worldConnections = connected.map(c => ({ ...c, outward: c.outward ? unit(vector(scopePose, c.outward)) : undefined }));
            const guidedAxes = guidedDirections(movingNode, worldConnections, dirs, remainingBoxes);
            // First, try the shortest proven withdrawal along each ray. When it
            // COLLIDES, every longer segment along precisely the same ray has
            // the same forbidden prefix; longer distances cannot repair it.
            // This is a search pruning rule, NOT an approval shortcut: every
            // accepted near segment, FAR transfer and replay is still checked.
            // Different axes and alternative routes remain eligible.
            for (const dir of guidedAxes) {
                const depths = nearDistances(movingNode, dir, worldConnections, remainingBoxes, work);
                for (let depthIndex = 0; depthIndex < depths.length; depthIndex++) {
                    const distance = depths[depthIndex];
                    stats.candidates++; stats.guidedCandidates!++; pulse();
                    const entry = poseMoved(scopePose, mul(dir, distance));
                    const rayKey = [scopeId, node.id, ...dir.map(n => n.toPrecision(16))].join('|');
                    const earlier = nearRayBlocks.get(rayKey);
                    // The blocker must still be at the same pose. Moving it to
                    // a staging bay invalidates the certificate, even though
                    // its part ID is still part of the imported model.
                    if (mayReuseBlockedNearRay(earlier, distance,
                        id => remaining.some(n => n.id === id),
                        id => staged.some(s => s.node.id === id))) {
                        stats.cachedNearRayRejects!++;
                        stats.avoidedNearDepthChecks! += depths.length - depthIndex - 1;
                        break;
                    }
                    firstSegmentBlocker = undefined;
                    if (!segmentClear(node, scopePose, entry, remaining, staged, scopePose, true, index)) {
                        stats.blockedNearRays!++;
                        stats.avoidedNearDepthChecks! += depths.length - depthIndex - 1;
                        const witness = firstSegmentBlocker as { id: string; staged: boolean } | undefined;
                        if (witness) {
                            const old = nearRayBlocks.get(rayKey);
                            if (!old || distance < old.depth)
                                nearRayBlocks.set(rayKey, { depth: distance, obstacleId: witness.id, staged: witness.staged });
                        }
                        break;
                    }
                    const tryFinish = (exit: M4): RouteResult | null => {
                        if (rotatedBay) {
                            const skyCentreY = ceiling - radius;
                            const exitCentre = point(exit, centre(node.bounds));
                            const air = poseMoved(exit, [0, skyCentreY - exitCentre[1], 0]);
                            if (!segmentClear(node, exit, air, remaining, staged, scopePose, false, index)) return null;
                            const turned = poseWithCentreAndYaw(node.bounds, point(air, centre(node.bounds)), yawOf(target));
                            if (!rotationEnvelopeClear(node, air, turned, remaining, staged, scopePose, index)) return null;
                            const targetCentre = point(target, centre(node.bounds));
                            const targetAir = poseMoved(target, [0, skyCentreY - targetCentre[1], 0]);
                            if (!segmentClear(node, turned, targetAir, remaining, staged, scopePose, false, index)) return null;
                            if (!segmentClear(node, targetAir, target, remaining, staged, scopePose, false, index)) return null;
                            return { poses: compactPoses([scopePose, entry, exit, air, turned, targetAir, target]) };
                        }
                        const high = ceiling - node.bounds.max[1];
                        const skyExit = poseMoved(exit, [0, high - pos(exit)[1], 0]);
                        const skyTarget = poseMoved(target, [0, high - pos(target)[1], 0]);
                        if (!segmentClear(node, exit, skyExit, remaining, staged, scopePose, false, index)) return null;
                        if (!segmentClear(node, skyExit, skyTarget, remaining, staged, scopePose, false, index)) return null;
                        if (!segmentClear(node, skyTarget, target, remaining, staged, scopePose, false, index)) return null;
                        return { poses: compactPoses([scopePose, entry, exit, skyExit, skyTarget, target]) };
                    };
                    // The direct overhead lane is the cheapest possible FAR
                    // transfer for exposed bricks. Try it BEFORE side exits,
                    // all with the same collision and final replay certificates.
                    // Defer expensive configuration-space routing until the
                    // ordinary guided pass has tried every eligible component.
                    // The first certified NEAR pose is a valid starting state
                    // only after every remaining connector has disengaged.
                    if (!detourSeed && !rotatedBay) {
                        const engagement = worldConnections.flatMap(c => [
                            ...(c.region ? [c.region.length] : []),
                            ...(c.regions ?? []).map(r => r.length),
                        ]).reduce((a, b) => Math.max(a, b), 0);
                        const matching = worldConnections.every(c => !c.outward ||
                            dot(dir, c.outward) > .98 || (c.axial && dot(dir, c.outward) < -.98));
                        if (matching && distance + SKIN >= engagement)
                            detourSeed = { entry, finish: tryFinish };
                    }
                    stats.directSkyAttempts!++;
                    const direct = tryFinish(entry);
                    if (direct) {
                        stats.directSkySuccesses!++;
                        return direct;
                    }
                    const entryBox = stagedBounds(node.bounds, entry);
                    for (const offset of farExits(entryBox, work, gap)) {
                        if (norm(offset) < 1e-9) continue; // already checked
                        const exit = poseMoved(entry, offset);
                        if (!segmentClear(node, entry, exit, remaining, staged, scopePose, false, index)) continue;
                        const finished = tryFinish(exit);
                        if (finished) return finished;
                    }
                }
            }
        }
        // A difficult Technic component may have a certified axial withdrawal
        // but no direct overhead/one-turn exit. Before the combinatorial V2
        // fallback, search a SMALL nonuniform configuration-space roadmap.
        // Every graph edge uses segmentClear(); the winning route is replayed
        // against the complete staged scene like every other V3 operation.
        // This search never rotates an engaged joint or bypasses its geometry.
        if (guided && mayDetour && options.enableConfigurationDetours !== false && detourSeed) {
            const seed = detourSeed;
            const moving = stagedBounds(node.bounds, seed.entry);
            const original = pos(seed.entry);
            const range: V3 = [240, 128, 240];
            const nearby = index?.touching({
                min: sub(moving.min, range), max: add(moving.max, range),
            }, node.id).map(item => item.box) ?? [
                ...remaining.filter(n => n !== node).map(n => stagedBounds(n.bounds, scopePose)),
                ...staged.map(s => stagedBounds(s.node.bounds, s.pose)),
            ];
            const tailHolder: { result: RouteResult | null } = { result: null };
            stats.configurationDetourAttempts!++;
            const search = findCertifiedDetour({
                start: original, moving, obstacles: nearby, scope: work, floor: ground,
                sky: ceiling, pulse, maxExpanded: 64, maxEdges: 210, maxFinishChecks: 48, maxMilliseconds: 350,
                clearEdge: (from, to) => segmentClear(node,
                    poseMoved(seed.entry, sub(from, original)),
                    poseMoved(seed.entry, sub(to, original)),
                    remaining, staged, scopePose, false, index),
                complete: (at) => {
                    tailHolder.result = seed.finish(poseMoved(seed.entry, sub(at, original)));
                    return tailHolder.result ? [] : null;
                },
                report: result => {
                    stats.configurationDetourStates! += result.expanded;
                    stats.configurationDetourEdges! += result.edges;
                },
            });
            if (search && tailHolder.result) {
                const tail = tailHolder.result;
                stats.configurationDetourSuccesses!++;
                return { poses: compactPoses([
                    scopePose, seed.entry,
                    ...search.waypoints.slice(1).map(at => poseMoved(seed.entry, sub(at, original))),
                    ...tail.poses.slice(3),
                ]) };
            }
        }
        // A connector-guided straight departure can be impossible even when a
        // short *bent* disengagement exists. Search from the ASSEMBLED pose as
        // a separate bounded fallback. Only the FIRST edge receives existing
        // verified departure/contact policies; all later edges use ordinary
        // swept collision queries. This is deliberately not a joint solver:
        // parts that need simultaneous articulation remain unsupported.
        if (guided && mayDetour &&
            options.enableConfigurationDetours !== false && !detourSeed && !rotatedBay) {
            const moving = stagedBounds(node.bounds, scopePose);
            const original = pos(scopePose);
            const range: V3 = [180, 96, 180];
            const nearby = index?.touching({
                min: sub(moving.min, range), max: add(moving.max, range),
            }, node.id).map(item => item.box) ?? [
                ...remaining.filter(n => n !== node).map(n => stagedBounds(n.bounds, scopePose)),
                ...staged.map(s => stagedBounds(s.node.bounds, s.pose)),
            ];
            const tailHolder: { poses: M4[] } = { poses: [] };
            stats.configurationDetourAttempts!++;
            stats.engagedDetourAttempts = (stats.engagedDetourAttempts ?? 0) + 1;
            const result = findCertifiedDetour({
                start: original, moving, obstacles: nearby, scope: work,
                floor: ground, sky: ceiling, pulse,
                maxExpanded: 56, maxEdges: 190, maxFinishChecks: 36, maxMilliseconds: 300,
                clearEdge: (from, to) => segmentClear(node,
                    poseMoved(scopePose, sub(from, original)),
                    poseMoved(scopePose, sub(to, original)),
                    remaining, staged, scopePose,
                    // No surface/mate policy persists after the very first
                    // segment; allowing one later would be unsafe.
                    norm(sub(from, original)) < 1e-7, index),
                complete: at => {
                    const exit = poseMoved(scopePose, sub(at, original));
                    const high = ceiling - node.bounds.max[1];
                    const skyExit = poseMoved(exit, [0, high - pos(exit)[1], 0]);
                    const skyTarget = poseMoved(target, [0, high - pos(target)[1], 0]);
                    if (!segmentClear(node, exit, skyExit, remaining, staged, scopePose, false, index) ||
                        !segmentClear(node, skyExit, skyTarget, remaining, staged, scopePose, false, index) ||
                        !segmentClear(node, skyTarget, target, remaining, staged, scopePose, false, index)) return null;
                    tailHolder.poses = [skyExit, skyTarget, target];
                    return [];
                },
                report: result => {
                    stats.configurationDetourStates! += result.expanded;
                    stats.configurationDetourEdges! += result.edges;
                },
            });
            if (result && tailHolder.poses.length) {
                stats.configurationDetourSuccesses!++;
                stats.engagedDetourSuccesses = (stats.engagedDetourSuccesses ?? 0) + 1;
                return { poses: compactPoses([
                    scopePose,
                    ...result.waypoints.slice(1).map(at => poseMoved(scopePose, sub(at, original))),
                    ...tailHolder.poses,
                ]) };
            }
        }
        // Exhaustive routing is deferred until EVERY eligible piece in the
        // current search state has been tried using short guided NEAR/FAR paths.
        // Failed near-route candidates are not proof of impossibility; the old
        // method is still available as the second pass when necessary.
        if (!allowExhaustive) return null;
        for (const dir of dirs) for (const distance of distances) {
            stats.candidates++; stats.exhaustiveCandidates!++;
            pulse();
            const entry = poseMoved(scopePose, mul(dir, distance));
            if (!segmentClear(node, scopePose, entry, remaining, staged, scopePose, true, index)) continue;
            const p = pos(entry), entryBox = stagedBounds(node.bounds, entry);
            const slides: V3[] = [8, 16, 24, 32, 48, 64].flatMap(d => ([[d, 0, 0], [-d, 0, 0], [0, 0, d], [0, 0, -d]] as V3[]));
            const exits: M4[] = [entry, ...slides.map(d => poseMoved(entry, d)),
                poseMoved(entry, [work.min[0] - entryBox.max[0] - gap, 0, 0]),
                poseMoved(entry, [work.max[0] - entryBox.min[0] + gap, 0, 0]),
                poseMoved(entry, [0, 0, work.min[2] - entryBox.max[2] - gap]),
                poseMoved(entry, [0, 0, work.max[2] - entryBox.min[2] + gap])];
            for (const exit of exits) {
                if (!segmentClear(node, entry, exit, remaining, staged, scopePose, false, index)) continue;
                if (rotatedBay) {
                    // Lift ABOVE the full 3D turning sphere before yawing. Rotation
                    // is applied to the entire finished group, not its individual
                    // pieces, and is undone on the flight back into its parent.
                    const skyCentreY = ceiling - radius;
                    const exitCentre = point(exit, centre(node.bounds));
                    const air = poseMoved(exit, [0, skyCentreY - exitCentre[1], 0]);
                    if (!segmentClear(node, exit, air, remaining, staged, scopePose, false, index)) continue;
                    const turned = poseWithCentreAndYaw(node.bounds, point(air, centre(node.bounds)), yawOf(target));
                    if (!rotationEnvelopeClear(node, air, turned, remaining, staged, scopePose, index)) continue;
                    const targetCentre = point(target, centre(node.bounds));
                    const targetAir = poseMoved(target, [0, skyCentreY - targetCentre[1], 0]);
                    if (!segmentClear(node, turned, targetAir, remaining, staged, scopePose, false, index)) continue;
                    if (!segmentClear(node, targetAir, target, remaining, staged, scopePose, false, index)) continue;
                    return { poses: compactPoses([scopePose, entry, exit, air, turned, targetAir, target]) };
                }
                const high = ceiling - node.bounds.max[1];
                const skyExit = poseMoved(exit, [0, high - pos(exit)[1], 0]);
                const skyTarget = poseMoved(target, [0, high - pos(target)[1], 0]);
                if (!segmentClear(node, exit, skyExit, remaining, staged, scopePose, false, index)) continue;
                if (!segmentClear(node, skyExit, skyTarget, remaining, staged, scopePose, false, index)) continue;
                if (!segmentClear(node, skyTarget, target, remaining, staged, scopePose, false, index)) continue;
                return { poses: compactPoses([scopePose, entry, exit, skyExit, skyTarget, target]) };
            }
        }
        // Preserve the original conservative 90-degree free-piece escape for
        // difficult fixed-orientation routes. No extra degrees of freedom are
        // silently granted at an occupied assembly point.
        if (!rotatedBay) {
            const pivot = centre(node.bounds), rotationAxes = unique([[1, 0, 0], [0, 1, 0], [0, 0, 1], ...axisDirections(node.matrix)] as V3[]);
            const rotationDistances = [...new Set([...distances, 64, 96, Math.max(96, extent * 2 + gap)])];
            for (const dir of dirs) for (const distance of rotationDistances) {
                stats.candidates++; stats.exhaustiveCandidates!++;
                pulse();
                const entry = poseMoved(scopePose, mul(dir, distance));
                if (!segmentClear(node, scopePose, entry, remaining, staged, scopePose, true, index)) continue;
                const entryCentre = point(entry, pivot);
                const radius = norm(mul(size(node.bounds), .5)), skyY = ceiling - radius;
                const skyEntry = poseMoved(entry, [0, skyY - entryCentre[1], 0]);
                for (const axis of rotationAxes) for (const angle of [Math.PI / 2, -Math.PI / 2]) {
                    const direction = unit(vector(scopePose, axis));
                    const turn = (at: M4): M4 => multiply(rigidDelta(ZERO, point(at, pivot), direction, angle), at);
                    const targetCentre = point(target, pivot);
                    const skyTarget = poseMoved(target, [0, skyY - targetCentre[1], 0]);
                    const rotatedTarget = turn(skyTarget);
                    // Preserve the existing V2 route that rotates immediately
                    // after a certified withdrawal. This can clear an overhang
                    // that would obstruct an unrotated vertical ascent.
                    const rotatedEntry = turn(entry), rotatedSkyEntry = turn(skyEntry);
                    if (rotationEnvelopeClear(node, entry, rotatedEntry, remaining, staged, scopePose, index) &&
                        segmentClear(node, rotatedEntry, rotatedSkyEntry, remaining, staged, scopePose, false, index) &&
                        segmentClear(node, rotatedSkyEntry, rotatedTarget, remaining, staged, scopePose, false, index) &&
                        rotationEnvelopeClear(node, rotatedTarget, skyTarget, remaining, staged, scopePose, index) &&
                        segmentClear(node, skyTarget, target, remaining, staged, scopePose, false, index))
                        return { poses: compactPoses([scopePose, entry, rotatedEntry, rotatedSkyEntry, rotatedTarget, skyTarget, target]) };
                    // Additional safe escape: climb into an empty air lane first,
                    // then rotate inside the sphere above the entire scene.
                    if (!segmentClear(node, entry, skyEntry, remaining, staged, scopePose, false, index)) continue;
                    if (!rotationEnvelopeClear(node, skyEntry, rotatedSkyEntry, remaining, staged, scopePose, index)) continue;
                    if (!segmentClear(node, rotatedSkyEntry, rotatedTarget, remaining, staged, scopePose, false, index)) continue;
                    if (!rotationEnvelopeClear(node, rotatedTarget, skyTarget, remaining, staged, scopePose, index)) continue;
                    if (!segmentClear(node, skyTarget, target, remaining, staged, scopePose, false, index)) continue;
                    return { poses: compactPoses([scopePose, entry, skyEntry, rotatedSkyEntry, rotatedTarget, skyTarget, target]) };
                }
            }
        }
        return null;
    };
    const solve = (nodes: ConstructionNode[], pose: M4, scopeId: string): Removal[] => {
        phase = 'route-search';
        scope = scopeId;
        lastBlockages = [];
        type Frame = { remaining: ConstructionNode[]; candidates: ConstructionNode[]; next: number; exhaustive: boolean; detouring?: boolean; detourCandidates?: ConstructionNode[]; savedGuidedNext?: number; partialDetourDone?: boolean; enteredAt: number; exhaustiveAttempted?: number; detoursAttempted?: number; support: Map<string, Removal['support']>; staged: StagedObstacle[]; index?: ScopeSceneIndex };
        // An earlier guided failure is useful order information, not proof of
        // impossibility: moving another part can free a previously blocked
        // route. Prioritize never-tried nodes and nodes with changed witnesses;
        // always retain every candidate and the exhaustive fallback.
        const guidedFailures = new Map<string, Set<string>>();
        const failed = new Set<string>(), stateKey = (r: ConstructionNode[]) => JSON.stringify(r.map(n => n.id));
        // Resolve graph edges ONCE per scope. Testing every candidate against
        // every dependency, then scanning all remaining siblings for every edge,
        // had cubic-ish cost on large authored models before route search even ran.
        const owner = new Map<string, string>();
        for (const n of nodes) { owner.set(n.id, n.id); n.leaves.forEach(id => owner.set(id, n.id)); }
        const dependencies = new Map<string, Set<string>>();
        const neighbours = new Map<string, Set<string>>();
        const link = (map: Map<string, Set<string>>, a: string, b: string) => {
            const list = map.get(a) ?? new Set<string>(); list.add(b); map.set(a, list);
        };
        for (const d of graph.dependencies) {
            const a = owner.get(d.parent), b = owner.get(d.child);
            if (a && b && a !== b) link(dependencies, a, b);
        }
        const outgoing = new Map<string, { connection: Connection; parentId: string }[]>();
        const activeLinks = new Map<string, { id: string; peer: string }[]>();
        const storeLink = (part: string, peer: string, id: string) => {
            const links = activeLinks.get(part) ?? [];
            links.push({ id, peer });
            activeLinks.set(part, links);
        };
        // Matched shadow joints are useful direction hints, but static-only
        // metadata must NOT create a support dependency or a motion exemption.
        const guidedOutgoing = new Map<string, { connection: Connection; parentId: string }[]>();
        for (const c of graph.connections) {
            if (c.staticOnly && c.id.startsWith('profiled:') && c.outward) {
                const a = owner.get(c.parent), b = owner.get(c.child);
                if (a && b && a !== b) {
                    const hints = guidedOutgoing.get(b) ?? [];
                    hints.push({ connection: c, parentId: a });
                    guidedOutgoing.set(b, hints);
                }
            }
            if (c.kind === 'surface' || c.staticOnly) continue;
            const a = owner.get(c.parent), b = owner.get(c.child);
            if (a && b && a !== b) {
                link(neighbours, a, b); link(neighbours, b, a);
                if (c.kind !== 'support') {
                    storeLink(a, b, c.id);
                    storeLink(b, a, c.id);
                }
                const bucket = outgoing.get(b) ?? [];
                bucket.push({ connection: c, parentId: a });
                outgoing.set(b, bucket);
            }
        }
        let closestUnresolved = nodes.map(n => n.id);
        const frame = (remaining: ConstructionNode[], chosen: Removal[]): Frame => {
            if (remaining.length < closestUnresolved.length) {
                closestUnresolved = remaining.map(n => n.id);
                stats.peakRemovals = nodes.length - remaining.length;
                stats.peakScopeUnits = nodes.length;
                const totalLeaves = nodes.reduce((total,n)=>total+n.leaves.length, 0);
                stats.peakRemovedLeaves = totalLeaves - remaining.reduce((total,n)=>total+n.leaves.length, 0);
                stats.peakScopeLeaves = totalLeaves;
                stats.peakScope = scopeId;
            }
            stats.states++;
            pulse();
            const present = new Set(remaining.map(n => n.id));
            const supportKinds = new Map<string, Removal['support']>();
            const candidates = remaining.filter(n => {
                if ([...(dependencies.get(n.id) ?? [])].some(id => present.has(id))) return false;
                const table = Math.abs(stagedBounds(n.bounds, pose).max[1] - ground) <= SKIN;
                const attached = [...(neighbours.get(n.id) ?? [])].some(id => present.has(id));
                if (!table && !attached && options.supportMode === 'table') return false;
                supportKinds.set(n.id, table ? 'table' : attached ? 'connected' : 'virtual-fixture');
                return true;
            });
            const staged = chosen.map(r => ({ node: r.node, pose: slots.get(r.node.id)!.pose }));
            const stagedIds = new Set(staged.map(s => s.node.id));
            const stillBlocked = (id: string): number => {
                const witnesses = guidedFailures.get(id);
                if (!witnesses?.size) return 0;
                // A witnessed blocker moved out of its original scope makes
                // the guided candidate worth retrying. This ranking never
                // suppresses a candidate, even when every witness remains.
                return [...witnesses].every(b => b === 'floor' || present.has(b) || stagedIds.has(b)) ? 1 : 0;
            };
            const blockedScores = guided ? new Map(candidates.map(n => [n.id, stillBlocked(n.id)])) : undefined;
            // A component blocking several already-observed withdrawal rays is
            // a useful prerequisite candidate. This never creates an artificial
            // dependency: it changes only search priority, and every candidate
            // still needs a certified route.
            const unblockCounts = new Map<string, number>();
            if (guided) for (const [blockedId, witnessed] of guidedFailures) {
                if (!present.has(blockedId)) continue;
                for (const b of witnessed) if (present.has(b) && b !== blockedId)
                    unblockCounts.set(b, (unblockCounts.get(b) ?? 0) + 1);
            }
            candidates.sort((a, b) => guided
                ? (blockedScores!.get(a.id)! - blockedScores!.get(b.id)!) ||
                    (unblockCounts.get(b.id) ?? 0) - (unblockCounts.get(a.id) ?? 0) ||
                    b.step - a.step || b.order - a.order || a.id.localeCompare(b.id)
                : Number(a.bounds.max[1] + pose[13] >= ground - SKIN) - Number(b.bounds.max[1] + pose[13] >= ground - SKIN) || a.bounds.min[1] - b.bounds.min[1] || b.step - a.step || b.order - a.order || a.id.localeCompare(b.id));
            return { remaining, candidates, next: 0, exhaustive: !guided, enteredAt: stats.milliseconds, support: supportKinds, staged, index: new ScopeSceneIndex(remaining, staged, pose) };
        };
        // Exhaustive 90-degree/sidestep searches can otherwise occupy the full
        // budget in one irreducible large-model state. V3 gives that fallback a
        // per-state effort allowance and then tries a different removal order.
        // This is a bounded search POLICY, not a collision tolerance: every
        // successful route is fully certified. Small scopes retain unbounded
        // (up to user limits) exhaustive fallback for backward compatibility.
        const exhaustiveBranchAllowance = guided && nodes.length >= 120
            ? Math.min(1536, Math.max(384, nodes.length * 3)) : Infinity;
        // Bound costly C-space exploration across ALL states, not only each
        // individual route. Deep, ordinary brick assemblies must retain enough
        // time for candidate ordering and local straight-line withdrawals.
        const detourAllowance = Math.max(2, Math.min(16, Math.floor(maxMilliseconds / 6000)));
        let detoursSpent = 0;
        let scopeBranchCuts = 0;
        const chosen: Removal[] = [], stack: Frame[] = [frame(nodes, chosen)];
        // Candidate search can test tens of thousands of short rays. Publishing
        // every attempt across the Web Worker boundary flooded the UI with
        // identical updates. Report changed progress at most ~10 Hz and emit a
        // heartbeat during a difficult candidate at most four times a second.
        let reportedCount = -1, reportedAt = -Infinity;
        while (stack.length) {
            pulse();
            const f = stack[stack.length - 1];
            if (options.onProgress && (reportedCount < 0 ||
                (chosen.length !== reportedCount && stats.milliseconds - reportedAt >= 100) ||
                stats.milliseconds - reportedAt >= 250)) {
                options.onProgress({ phase: 'disassembly', completed: chosen.length, total: nodes.length, item: scopeId });
                reportedCount = chosen.length;
                reportedAt = stats.milliseconds;
            }
            if (!f.remaining.length) return chosen;
            if (f.exhaustive && guided &&
                (f.exhaustiveAttempted ?? 0) >= exhaustiveBranchAllowance) {
                f.next = f.candidates.length;
                stats.boundedExhaustiveBranches!++;
                scopeBranchCuts++;
            }
            // A large scope can spend its entire budget walking the guided
            // candidate list without EVER reaching the exhaustive phase. After
            // a measured stall, run a small number of constrained detours now,
            // then resume the normal list at precisely the saved cursor.
            if (guided && !f.exhaustive && !f.detouring && !f.partialDetourDone &&
                options.enableConfigurationDetours !== false && detoursSpent < detourAllowance &&
                f.next >= 32 && stats.milliseconds - f.enteredAt >= 500) {
                f.partialDetourDone = true;
                const present = new Set(f.remaining.map(n => n.id));
                const coupled = (n: ConstructionNode) =>
                    [...(outgoing.get(n.id) ?? []), ...(guidedOutgoing.get(n.id) ?? [])]
                        .some(link => present.has(link.parentId));
                const attempted = f.candidates.slice(0, f.next);
                f.detourCandidates = attempted.filter(n => guidedFailures.has(n.id) && coupled(n)).slice(0, 2);
                if (f.detourCandidates.length) {
                    f.savedGuidedNext = f.next;
                    f.detouring = true;
                    f.next = 0;
                    continue;
                }
            }
            const activeCandidates = f.detouring ? (f.detourCandidates ?? []) : f.candidates;
            if (f.next >= activeCandidates.length) {
                if (f.detouring && f.savedGuidedNext !== undefined) {
                    // Restore the exact guided cursor, so the detour experiment
                    // never skips an eligible candidate or removes the fallback.
                    f.detouring = false;
                    f.next = f.savedGuidedNext;
                    f.savedGuidedNext = undefined;
                    continue;
                }
                if (guided && !f.exhaustive && f.candidates.length) {
                    if (!f.detouring && options.enableConfigurationDetours !== false && detoursSpent < detourAllowance) {
                        // The guided phase failed for *every* available piece.
                        // Before trying hundreds of arbitrary V2 paths, examine
                        // up to two blocked mechanical parts in full 3D. This
                        // phase never suppresses the subsequent V2 fallback.
                        const available = new Set(f.remaining.map(n => n.id));
                        const hasJoint = (node: ConstructionNode) =>
                            [...(outgoing.get(node.id) ?? []), ...(guidedOutgoing.get(node.id) ?? [])]
                              .some(link => available.has(link.parentId));
                        f.detourCandidates = f.candidates.filter(n => guidedFailures.has(n.id) && hasJoint(n)).slice(0, 2);
                        if (f.detourCandidates.length) {
                            f.detouring = true;
                            f.next = 0;
                            continue;
                        }
                    }
                    // C-space exploration is bounded; the original detailed
                    // V2 proposal search is still available when it fails.
                    f.detouring = false;
                    f.exhaustive = true;
                    f.exhaustiveAttempted = 0;
                    f.next = 0;
                    continue;
                }
                failed.add(stateKey(f.remaining)); stack.pop();
                if (chosen.length) chosen.pop();
                stats.backtracks++;
                continue;
            }
            const node = activeCandidates[f.next++], remaining = f.remaining.filter(n => n !== node);
            if (failed.has(stateKey(remaining))) continue;
            // Retain only the ACTIVE search state's broad-phase tree. Keeping
            // a tree for every level of a thousand-brick DFS would consume
            // quadratic memory. Rebuild a previous level only on backtracking.
            f.index ??= new ScopeSceneIndex(f.remaining, f.staged, pose);
            const present = new Set(f.remaining.map(n => n.id));
            const connected = [...(outgoing.get(node.id) ?? []), ...(guided ? guidedOutgoing.get(node.id) ?? [] : [])]
                .filter(c => present.has(c.parentId)).map(c => c.connection);
            const previouslyBlocked = guided && !f.exhaustive && guidedFailures.has(node.id);
            if (previouslyBlocked) stats.deferredPreviouslyBlockedNodes!++;
            activeRouteWitnesses = guided && !f.exhaustive ? new Set<string>() : undefined;
            const exhaustiveBefore = stats.exhaustiveCandidates ?? 0;
            // Roadmap fallback is more expensive than ordinary connector-guided
            // motion. Bound it per search state so a mechanically interlocked
            // candidate cannot starve all the other valid removal orders.
            const tryDetour = !!(guided && detoursSpent < detourAllowance &&
                (f.detouring || (f.exhaustive && (f.detoursAttempted ?? 0) < 2 &&
                (connected.length > 0 || (f.detoursAttempted ?? 0) === 0))));
            if (tryDetour) {
                detoursSpent++;
                f.detoursAttempted = (f.detoursAttempted ?? 0) + 1;
            }
            const result = route(node, f.remaining, f.staged, pose, scopeId, f.index, f.exhaustive, connected, tryDetour);
            if (f.exhaustive) f.exhaustiveAttempted = (f.exhaustiveAttempted ?? 0) + (stats.exhaustiveCandidates! - exhaustiveBefore);
            const observed = activeRouteWitnesses;
            activeRouteWitnesses = undefined;
            if (!result) {
                if (observed?.size && !f.exhaustive) guidedFailures.set(node.id, observed);
                continue;
            }
            guidedFailures.delete(node.id);
            const stillPresent = new Set(remaining.map(n => n.id));
            const connections = (activeLinks.get(node.id) ?? []).filter(link => stillPresent.has(link.peer)).map(link => link.id);
            chosen.push({ node, poses: result.poses, connections, support: f.support.get(node.id)! });
            f.index = undefined;
            stack.push(frame(remaining, chosen));
        }
        // Floor rejections routinely come from deliberately probing a downward
        // axis. They should not hide the true mesh withdrawal obstruction.
        const meaningful = lastBlockages.filter(b => b.stage !== 'floor');
        const diagnostics = meaningful.length ? meaningful : lastBlockages;
        throw new ConstructionError(scopeBranchCuts ? 'search-budget-exhausted' : 'no-supported-rigid-route',
            `No collision-certified rigid path was found in ${scopeId}; route search reached ${nodes.length - closestUnresolved.length}/${nodes.length} placed-removal candidates before failing. ` +
            (scopeBranchCuts ? `${scopeBranchCuts} exhaustive search branches were effort-bounded; the solver has NOT explored every physical route. ` : '') +
            'The listed contacts are search obstructions, not proof the model is impossible.',
            { scope: scopeId, items: closestUnresolved, blockages: diagnostics.slice(0, 12), stats: { ...stats } });
    };
    const operations: Operation[] = [], warnings = [...graph.warnings, ...contactWarnings];
    if (guided) warnings.push('Construction V3 uses connector-guided NEAR/FAR paths, scoped swept-collision indexing, witnessed blocked-ray reuse, and bounded exhaustive fallback on large scopes. Only candidate search is pruned: every accepted route undergoes the existing continuous mesh checks and independent forward replay.');
    if (stepModules.modules) warnings.push(`${stepModules.members} bricks organized into ${stepModules.modules} authored-step connected workbench modules. Every individual brick is still assembled and swept-collision-verified within its module; module attachment is checked as a rigid group.`);
    if (composite.groups) warnings.push(`${composite.segments} LDraw flexible render segments grouped into ${composite.groups} pre-shaped composite parts. The composites move as one rigid shape; bending or manufacturing the hose is not simulated. All contacts with OTHER parts remain collision-checked.`);
    const unoriented = [...new Set([...model.parts.values()].map(n => n.part!))].filter(id => { const m = model.metrics(id); return m.meshTwoSidedFrom !== undefined && m.meshTwoSidedFrom < m.mesh!.length / 9; });
    if (unoriented.length)
        warnings.push(`Some mesh faces have unknown orientation (${unoriented.join(', ')}); containment assumes reasonably consistent winding and is not a solid-CAD certificate.`);
    const compile = (nodes: ConstructionNode[], pose: M4, scopeId: string) => {
        const removals = solve(nodes, pose, scopeId);
        for (const removal of [...removals].reverse()) {
            const n = removal.node;
            if (n.children?.length && !n.atomic)
                compile(n.children, slots.get(n.id)!.pose, n.id);
            const id = `construct:${n.id}`, previous = operations[operations.length - 1];
            const poses = [...removal.poses].reverse();
            // Use the existing lightweight translation track only when EVERY
            // waypoint is in the imported orientation. Angled scopes use full
            // rigid matrices, including at their staging/attachment endpoints.
            const rigid = poses.some(p => !isIdentityOrientation(p));
            operations.push({ id, kind: n.children && !n.atomic ? 'attach-subassembly' : removal.connections.length ? 'connect' : 'place', keys: [...n.leaves], scope: scopeId, model: n.model, step: n.step,
                requires: previous ? [previous.id] : [], connections: removal.connections,
                path: poses.map(pos), rigidPath: rigid ? poses : undefined,
                check: { method: 'continuous-triangle-sat', contactPolicies: graph.connections.filter(c => hasMotionPolicy(c) && owns(n, c.child)).map(c => c.id), support: removal.support } });
        }
    };
    const routeStarted = performance.now();
    if (model.parts.size)
        compile(rootNodes, rigidDelta(ZERO), '$root');
    stats.routeMilliseconds = Math.round(performance.now() - routeStarted);

    // Verify the whole FORWARD scene with true staged orientations. The earlier
    // algorithm replayed only translation offsets and therefore could not tell
    // whether an angled group's members really ended in their correct bay pose.
    phase = 'forward-replay';
    const replayStarted = performance.now();
    const current = new Map([...model.parts.keys()].map(key => [key, slots.get(key)!.pose]));
    const closePose = (a: readonly number[], b: readonly number[]) => a.every((v, i) => Math.abs(v - b[i]) < 1e-6);
    for (const [index, op] of operations.entries()) {
        pulse();
        options.onProgress?.({ phase: 'validation', completed: index, total: operations.length, item: op.id });
        const moving = new Set(op.keys);
        const poses: M4[] = op.rigidPath ?? op.path.map(p => rigidDelta(p));
        const first = poses[0], last = poses[poses.length - 1];
        for (const key of op.keys)
            if (!closePose(current.get(key)!, first))
                throw new ConstructionError('invalid-plan', `Discontinuous staged orientation or position for ${key} in ${op.id}.`);
        const movingBounds = op.keys.map(key => model.parts.get(key)!.bounds).reduce(union);
        for (let i = 1; i < poses.length; i++) {
            const from = poses[i - 1], to = poses[i];
            // An assembly constructed on its final studs never travels. Do not
            // run a motion-collision certificate for a zero-length segment.
            if (closePose(from, to)) continue;
            if (!sameOrientation(from, to)) {
                const before = point(from, centre(movingBounds)), after = point(to, centre(movingBounds));
                const sphere = turningSphere(movingBounds, from);
                if (norm(sub(before, after)) > 1e-6 || sphere.max[1] > ground + SKIN)
                    throw new ConstructionError('invalid-plan', `Replay cannot certify the pivot or floor clearance for ${op.id}.`);
                for (const [key, where] of current) {
                    if (!moving.has(key) && overlaps(sphere, stagedBounds(model.parts.get(key)!.bounds, where)))
                        throw new ConstructionError('invalid-plan', `Replay cannot certify continuous rotation of ${op.id} near ${key}.`, {
                            scope: op.scope, blockages: [{ moving: op.id, obstacle: key, stage: 'transport', detail: 'The continuous rotation sphere intersects actual staged/assembled geometry.' }], stats: { ...stats } });
                }
                continue;
            }
            const delta = sub(pos(to), pos(from));
            const worldBox = stagedBounds(movingBounds, from), endBox = stagedBounds(movingBounds, to);
            if (worldBox.max[1] > ground + SKIN || endBox.max[1] > ground + SKIN)
                throw new ConstructionError('invalid-plan', `Replay found an under-table path for ${op.id}.`);
            for (const a of op.keys) for (const [b, where] of current) {
                if (moving.has(b)) continue;
                // Exact, time-reversible mesh check in the same rigid frame.
                // An end-of-flight connector certificate only applies to the
                // final insertion segment, never to earlier transport.
                if (!clearSweep(a, b, to, from, where, i === poses.length - 1))
                    throw new ConstructionError('invalid-plan', `Replay rejected collision of ${a} with ${b} during ${op.id}.`, {
                        scope: op.scope, blockages: [{ moving: a, obstacle: b, stage: 'transport', detail: 'Continuous swept-mesh collision rejected the actual scene.' }], stats: { ...stats } });
            }
        }
        for (const key of op.keys) current.set(key, last);
    }
    for (const [key, pose] of current)
        if (!closePose(pose, rigidDelta(ZERO)))
            throw new ConstructionError('invalid-plan', `Final orientation or placement changed for ${key}.`);
    if (operations.some(o => o.check.support === 'virtual-fixture'))
        warnings.push('Some assembly operations require a held workpiece/virtual fixture. Fixtures are assumptions, not rendered supports; gravity and physical stability are not simulated.');
    if (operations.some(o => o.rigidPath))
        warnings.push('Rotated group transfers preserve each member\'s rigid relative pose. Every turn has a continuous obstacle-free sphere certificate and every translation is checked against the staged scene.');
    warnings.push('Automatic articulated-joint search and flexible/snap-fit deformation are not implemented; these fail explicitly rather than bypassing collision checks.');
    warnings.push('Mesh validation uses a 0.02 LDU numerical skin and oriented-mesh winding-number containment assumptions. Connector contact allowances are localized metadata, not a tolerance-free mechanical proof.');
    stats.replayMilliseconds = Math.round(performance.now() - replayStarted);
    stats.milliseconds = Math.round(performance.now() - start);
    return { schema: 'brickmotion-construction/v2', operations,
        parts: [...model.parts.values()].map(n => ({ key: n.id, part: n.part!, final: [...n.matrix], staged: multiply(slots.get(n.id)!.pose, n.matrix), bounds: n.bounds })),
        connections: graph.connections, dependencies: graph.dependencies, warnings, stats, workBays, ground, bounds: model.bounds, sceneBounds,
        capabilities: { rigidTranslation: true, rigidRotation: true, hierarchicalSubassemblies: true, articulation: false, deformation: false, physicalStability: false } };
}

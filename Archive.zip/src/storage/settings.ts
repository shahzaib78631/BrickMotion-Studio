import { get, set } from 'idb-keyval';
import { validateJointLimitRules, type JointLimitRule } from '../anim/motion/v4/jointLimits';
import { validateMechanismProgram, type MechanismProgram } from '../anim/motion/v4/mechanismProgram';
import { FLOOR_STYLES, type ArrivalMode, type FloorMatch, type FloorSides, type FloorSort, type FloorStyle } from '../anim/pacing';
import { isConstructionBudgetPreset, type ConstructionBudgetPreset } from '../anim/construction/budgetPresets';
import type { LogoCorner } from '../export/exportVideo';
import { isExportFps, type ExportFps } from '../export/frameRates';
import { DEFAULT_MATERIALS, isStudioLook, sanitizeMaterials, type Materials, type StudioLook } from '../render/looks';
import { DEFAULT_CAMERA_SETTINGS, type CameraFraming, type CameraSettings } from '../anim/camera';
import { isVideoFormat, type VideoFormat } from '../export/formats';

export type Settings = {
  apiKey: string;
  model: string;
  logo: Blob | null;
  logoCorner: LogoCorner;
  logoEnabled: boolean;
  /** the floating quick-action bar over the viewport when parts are selected */
  showSelectionBar: boolean;
  /** MP4 camera: automatic cinematics, or the camera the viewport plays. */
  exportCamera: 'automatic' | 'buildView';
  /** the Build viewport plays the intro shot and hero orbit while it plays */
  cameraFollowsPlayback: boolean;
  video: { targetSeconds: number; heroOrbit: boolean; mode: ArrivalMode | 'auto'; fps: ExportFps; introSeconds: number | null; buildSeconds: number | null; outroSeconds: number | null; studioLook: StudioLook; cameraFraming: CameraFraming; camera: CameraSettings; format: VideoFormat; edgeLines: boolean; linearColors: boolean; bottomUp: boolean; snapSound: boolean; planner?: 'legacy' | 'construction-v2' | 'construction-auto' | 'construction-v3' | 'construction-v3-auto' | 'construction-v4' | 'standard-motion' | 'standard-motion-v4' | 'assembly-artifact'; constructionSupport?: 'fixture' | 'table'; constructionBudget?: ConstructionBudgetPreset; constructionStepModules?: boolean; motionV4Limits?: JointLimitRule[]; motionV4Mechanism?: MechanismProgram | null; floorSort: FloorSort; floorSides: FloorSides; floorStyle: FloorStyle; floorMatch: FloorMatch; materials: Materials };
};

export const DEFAULT_SETTINGS: Settings = {
  apiKey: '',
  model: 'claude-opus-5-5',
  logo: null,
  logoCorner: 'br',
  logoEnabled: false,
  showSelectionBar: true,
  exportCamera: 'automatic',
  cameraFollowsPlayback: true,
  video: { targetSeconds: 15, heroOrbit: true, mode: 'auto', fps: 30, introSeconds: null, buildSeconds: null, outroSeconds: null, studioLook: 'soft', cameraFraming: 'cinematic', camera: DEFAULT_CAMERA_SETTINGS, format: '9:16', edgeLines: true, linearColors: true, bottomUp: true, snapSound: true, planner: 'legacy', constructionSupport: 'fixture', constructionBudget: 'standard', constructionStepModules: false, motionV4Limits: [], motionV4Mechanism: null, floorSort: 'step', floorSides: 'front-back', floorStyle: 'packed', floorMatch: 'fill', materials: DEFAULT_MATERIALS },
};

const KEY = 'settings';

export async function loadSettings(): Promise<Settings> {
  const s = (await get<Partial<Settings>>(KEY)) ?? {};
  const video = { ...DEFAULT_SETTINGS.video, ...(s.video ?? {}) };
  if (!isExportFps(video.fps)) video.fps = DEFAULT_SETTINGS.video.fps;
  if (!isStudioLook(video.studioLook)) video.studioLook = 'soft';
  video.materials = sanitizeMaterials(video.materials);
  if (!FLOOR_STYLES.includes(video.floorStyle)) video.floorStyle = 'packed';
  if (video.floorMatch !== 'nearest') video.floorMatch = 'fill';
  if (video.cameraFraming !== 'cinematic' && video.cameraFraming !== 'wide') video.cameraFraming = 'cinematic';
  video.camera = { ...DEFAULT_CAMERA_SETTINGS, ...(video.camera ?? {}) };
  delete (video.camera as Partial<Record<string, number>>).closeUpStrength; // replaced by submodelFocus
  const ranges: Record<keyof CameraSettings, [number, number]> = {
    lensMm: [18, 200], sensorWidthMm: [12, 70], buildAzimuth: [-180, 180], buildElevation: [15, 89],
    buildMargin: [1, 2], targetLock: [0, 1], submodelFocus: [0, 1], buildDrift: [-45, 45], damping: [0, 1],
    heroOrbitDegrees: [-360, 360], heroElevation: [5, 85], heroMargin: [1, 2],
  };
  for (const key of Object.keys(ranges) as (keyof CameraSettings)[]) {
    const [lo, hi] = ranges[key];
    const value = Number(video.camera[key]);
    video.camera[key] = Number.isFinite(value) ? Math.min(hi, Math.max(lo, value)) : DEFAULT_CAMERA_SETTINGS[key];
  }
  if (!isVideoFormat(video.format)) video.format = '9:16';
  if (typeof video.edgeLines !== 'boolean') video.edgeLines = DEFAULT_SETTINGS.video.edgeLines;
  if (typeof video.linearColors !== 'boolean') video.linearColors = DEFAULT_SETTINGS.video.linearColors;
  if (typeof video.bottomUp !== 'boolean') video.bottomUp = DEFAULT_SETTINGS.video.bottomUp;
  if (video.constructionSupport !== 'table') video.constructionSupport = 'fixture';
  if (!isConstructionBudgetPreset(video.constructionBudget)) video.constructionBudget = 'standard';
  if (typeof video.constructionStepModules !== 'boolean') video.constructionStepModules = false;
  if (!Array.isArray(video.motionV4Limits) || validateJointLimitRules(video.motionV4Limits).length > 0) video.motionV4Limits = [];
  if (video.motionV4Mechanism != null && validateMechanismProgram(video.motionV4Mechanism).length) video.motionV4Mechanism = null;
  if (!['construction-v2', 'construction-auto', 'construction-v3', 'construction-v3-auto', 'construction-v4', 'standard-motion', 'standard-motion-v4', 'assembly-artifact'].includes(video.planner ?? '')) video.planner = 'legacy';
  if (!['step', 'colour', 'part', 'size', 'all'].includes(video.floorSort)) video.floorSort = 'step';
  if (!['front-back', 'front', 'behind', 'sides', 'around'].includes(video.floorSides)) video.floorSides = 'front-back';
  if (typeof video.snapSound !== 'boolean') video.snapSound = DEFAULT_SETTINGS.video.snapSound;
  if (typeof s.showSelectionBar !== 'boolean') s.showSelectionBar = DEFAULT_SETTINGS.showSelectionBar;
  if (typeof s.cameraFollowsPlayback !== 'boolean') s.cameraFollowsPlayback = DEFAULT_SETTINGS.cameraFollowsPlayback;
  if (s.exportCamera !== 'automatic' && s.exportCamera !== 'buildView') s.exportCamera = 'automatic';
  for (const key of ['introSeconds', 'buildSeconds', 'outroSeconds'] as const) {
    const value = video[key];
    if (value !== null && (!Number.isFinite(value) || value < (key === 'buildSeconds' ? 1 : 0.2) || value > 120)) video[key] = null;
  }
  return { ...DEFAULT_SETTINGS, ...s, video };
}

export async function saveSettings(s: Settings): Promise<void> {
  await set(KEY, s);
}
